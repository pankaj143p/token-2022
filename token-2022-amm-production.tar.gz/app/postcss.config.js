module.exports = {
  content: [],
  plugins: [],
}
